<?php

// It's just a flag , the imported policy will always assigned as root
$policyType = "15.4";